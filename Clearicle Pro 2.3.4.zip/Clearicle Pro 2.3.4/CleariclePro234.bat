:start
start q
start w
start e
start r
start t
start y
start u
start i
start o
start p
goto :start